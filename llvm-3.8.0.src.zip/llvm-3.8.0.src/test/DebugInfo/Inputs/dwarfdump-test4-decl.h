inline void a(){}
