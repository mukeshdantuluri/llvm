#include <stdio.h>
#include <string>

__attribute__((noinline))
void foo() { printf("foo\n"); }
