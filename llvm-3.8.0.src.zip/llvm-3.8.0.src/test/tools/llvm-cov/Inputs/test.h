struct A {
  virtual void B();
};
