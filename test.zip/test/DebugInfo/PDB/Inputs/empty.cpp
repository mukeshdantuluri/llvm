// Build with "cl.exe /Zi empty.cpp /link /debug /nodefaultlib /entry:main"

void *__purecall = 0;

int main() {
  return 42;
}
