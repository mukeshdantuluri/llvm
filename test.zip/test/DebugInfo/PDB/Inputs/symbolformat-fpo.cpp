// Compile with "cl /GR- /Zi /c /Ox /Oy symbolformat-fpo.cpp"
// Refer to symbolformat.cpp for linking instructions.

unsigned fpo_func(unsigned n) {
  return n * 2;
}
