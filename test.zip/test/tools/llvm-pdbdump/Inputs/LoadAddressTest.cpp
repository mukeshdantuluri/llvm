// Compile with "cl /c /Zi /GR- LoadAddressTest.cpp"
// Link with "link LoadAddressTest.obj /debug /nodefaultlib /entry:main"

int main(int argc, char **argv) {
  return 0;
}
