// cl.exe -clr -c t.cpp -Fo"cxx-cli-aux.obj.coff-i386"
__declspec(appdomain) int PerAppDomain = 0;
