


#undef M1
#define M1 NewValue1
