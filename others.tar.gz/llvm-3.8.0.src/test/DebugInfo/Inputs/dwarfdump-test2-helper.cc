extern "C" int a() {
  return 0;
}
