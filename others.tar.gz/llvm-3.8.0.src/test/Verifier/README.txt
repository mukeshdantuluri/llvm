This directory contains testcases that the verifier is supposed to detect as
malformed LLVM code.  Testcases for situations that the verifier incorrectly
identifies as malformed should go in the test/Assembler directory.
